package priv.hk.game.dao;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import priv.hk.game.dto.Player;
/**
 * ��Ϊ���ӱ����ļ���һ���м���,���ڶ�ȡ�ļ��е������Ϣ,��������
 */
public class Disk {
	static List<Player> players = new ArrayList<Player>();
	
	public List<Player> readFile(){
		try {
			FileInputStream fis = new FileInputStream("disk.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);
			players = (List<Player>)ois.readObject();
			ois.close();
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return players;
	}
	
	public void writeFile(List<Player> players){
		try {
			FileOutputStream fos = new FileOutputStream("disk.dat");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			this.players = players;
			oos.writeObject(players);
			oos.close();
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
//		players.add(new Player("hk",100));
//		players.add(new Player("tj",200));
//		players.add(new Player("tl",300));
//		players.add(new Player("aa",400));
//		players.add(new Player("qq",500));
//		new Disk().writeFile(players);
//		players = new Disk().readFile();
//		for(int i=0;i<players.size();i++){
//			System.out.print(players.get(i).getName());
//			System.out.println(players.get(i).getPoint());
//		}
	}
}
