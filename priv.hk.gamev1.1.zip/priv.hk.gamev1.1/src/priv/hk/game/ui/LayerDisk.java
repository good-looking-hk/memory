package priv.hk.game.ui;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import priv.hk.game.dto.Player;
/**
 * ���ؼ�¼��,�д����ư�
 */
public class LayerDisk extends BasicLayer {
	List<Player> players = new ArrayList<Player>(7);
	public LayerDisk(int x, int y, int w, int h) {
		super(x, y, w, h);
	}
	
	@Override
	public void paint(Graphics g){
		this.createWindow(g);
		players = this.dto.getDiskRecord();
		g.drawImage(GameImage.IMG_DISK,this.x-3,this.y,null);
		for(int i=0;i<5;i++){
			//drawRect(g,1,46+i*44,0,players.get(i).getName(),players.get(i).getPoint());
		}
	}
}
