package priv.hk.game.ui;

import java.awt.Graphics;
/**
 * ������ʾ��Ϸ�ȼ�����
 */
public class LayerLevel extends BasicLayer{

	public LayerLevel(int x, int y, int w, int h) {
		super(x, y, w, h);
	}

	@Override
	public void paint(Graphics g){
		this.createWindow(g);
		g.drawImage(GameImage.IMG_LEVEL,this.x+10,this.y+10,null);
		drawNumber(this.dto.getLevel(), this.x-60, this.y+60, g);
	}
}
