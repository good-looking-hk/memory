package priv.hk.game.ui;

import java.awt.Image;

import javax.swing.ImageIcon;
/**
 * ��ϷͼƬ��
 */
public class GameImage {
	//����ͼƬ
	public static final Image BACKGROUND;
	//�߿�ͼƬ
	public static final Image BORDER;
	//����ͼƬ
	public static final Image IMG_BLOCK;
	//���ݿ�ͼƬ
	public static final Image IMG_DB;
	//���ؼ�¼ͼƬ
	public static final Image IMG_DISK;
	//���߽���
	public static final Image IMG_AUTHOR;
	//��ʼͼƬ
	public static final ImageIcon IMG_START;
	//�˳�ͼƬ
	public static final ImageIcon IMG_CONFIG;
	//�ȼ�ͼƬ
	public static final Image IMG_LEVEL;
	//����ͼƬ
	public static final Image IMG_POINT;
	//����ͼƬ
	public static final Image IMG_REMOVELINE;
	//��һ������ͼƬ����
	public static final Image[] IMG_BLOCKS = new Image[7];
	//����ͼƬ
	public static final Image IMG_NUMBER;
	//ֵ��ͼƬ
	public static final Image IMG_RECT;
	//Ϊ��̬��������ֵ
	static{
		BACKGROUND = new ImageIcon("graphics/background/Sea.jpg").getImage();
		BORDER = new ImageIcon("graphics/game/border.png").getImage();
		IMG_BLOCK = new ImageIcon("graphics/game/block.png").getImage();
		IMG_DB = new ImageIcon("graphics/string/db.png").getImage();
		IMG_DISK = new ImageIcon("graphics/string/disk.png").getImage();
		IMG_AUTHOR = new ImageIcon("graphics/string/author.png").getImage();
		IMG_START = new ImageIcon("graphics/string/start.png");
		IMG_CONFIG = new ImageIcon("graphics/string/config.png");
		IMG_LEVEL = new ImageIcon("graphics/string/level.png").getImage();
		IMG_POINT = new ImageIcon("graphics/string/point.png").getImage();
		IMG_REMOVELINE = new ImageIcon("graphics/string/xiaohang.png").getImage();
		for(int i=0;i<7;i++){
			IMG_BLOCKS[i] = new ImageIcon("graphics/game/"+i+".png").getImage();
		}
		IMG_NUMBER = new ImageIcon("graphics/string/number.png").getImage();
		IMG_RECT = new ImageIcon("graphics/string/rect.png").getImage();
	}
}
