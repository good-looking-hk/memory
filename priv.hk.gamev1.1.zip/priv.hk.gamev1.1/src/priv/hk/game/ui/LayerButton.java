package priv.hk.game.ui;

import java.awt.Graphics;
/**
 * ��ť��,�д�����
 */
public class LayerButton extends BasicLayer{

	public LayerButton(int x, int y, int w, int h) {
		super(x, y, w, h);
	}
	
	@Override
	public void paint(Graphics g){
		this.createWindow(g);
		//g.drawImage(GameImage.IMG_START,this.x+xx,this.y+yy,null);
		//g.drawImage(GameImage.IMG_CONFIG,this.x+xx+GameImage.IMG_START.getWidth(null)+xx,this.y+yy,null);
	}

}
