package priv.hk.game.ui;

import java.awt.Graphics;
/**
 * ������Ϸ��ʾ��һ���������
 */
public class LayerNext extends BasicLayer{

	public LayerNext(int x, int y, int w, int h) {
		super(x, y, w, h);
	}
	
	@Override
	public void paint(Graphics g){
		this.createWindow(g);
		int xx = (this.w-GameImage.IMG_BLOCKS[this.dto.getNextType()].getWidth(null))/2;
		int yy = (this.h-GameImage.IMG_BLOCKS[this.dto.getNextType()].getHeight(null))/2;
		if(this.dto.isGameStart()){
			g.drawImage(GameImage.IMG_BLOCKS[this.dto.getNextType()],this.x+xx,this.y+yy,null);
		}
	}
}
