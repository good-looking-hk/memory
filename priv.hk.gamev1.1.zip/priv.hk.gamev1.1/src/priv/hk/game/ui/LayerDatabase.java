package priv.hk.game.ui;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import priv.hk.game.dto.Player;
/**
 * ���ݿ���,�д����ư�
 */
public class LayerDatabase extends BasicLayer{
	List<Player> players = new ArrayList<Player>(7);
	public LayerDatabase(int x, int y, int w, int h) {
		super(x, y, w, h);
	}
	
	@Override
	public void paint(Graphics g){
		this.createWindow(g);
		players = this.dto.getDbRecord();
		g.drawImage(GameImage.IMG_DB,this.x,this.y+2,null);
		for(int i=0;i<5;i++){
//			drawRect(g,1,46+i*44,0,players.get(i).getName(),players.get(i).getPoint());
		}
	}
}
