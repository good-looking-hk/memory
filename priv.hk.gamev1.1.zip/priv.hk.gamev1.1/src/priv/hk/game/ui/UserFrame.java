package priv.hk.game.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UserFrame extends JFrame{
	JLabel label;
	JTextField tf_userName;
	JPanel panel1,panel2;
	JButton button_ok;
	public UserFrame(){
		super("�����Ϣ����");
		setLayout(new GridLayout(2,0));
		label = new JLabel("�������");
		tf_userName = new JTextField(10);
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel1.add(label);
		panel1.add(tf_userName);
		button_ok = new JButton("ȷ��");
		add(panel1);
		panel2.add(button_ok,BorderLayout.CENTER);
		add(panel2);
		setSize(200,100);
		setLocationRelativeTo(null);
		setVisible(true);
		
	}

	
	
	public static void main(String[] args) {
		new UserFrame();
	}
}
