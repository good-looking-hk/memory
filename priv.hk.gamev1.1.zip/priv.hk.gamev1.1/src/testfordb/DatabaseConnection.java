package testfordb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
	static Statement statement; 
	public DatabaseConnection() throws Exception{
		String url = "jdbc:mysql://localhost:3306/game";
		String username = "root";
		String password = "199710";
		Class.forName("com.mysql.jdbc.Driver");
		Connection connection = DriverManager.getConnection(url,username,password);
		statement = connection.createStatement();
	}
	public static ResultSet show() throws SQLException{
		String sql = "select * from player";
		ResultSet rs = statement.executeQuery(sql);
		return rs;
	}
	
	public static void add(String sql) throws SQLException{
		statement.executeUpdate(sql);
	}
	
	public static void delete(String sql) throws SQLException{
		statement.executeUpdate(sql);
	}
	
	public static void modify(String sql) throws SQLException{
		statement.execute(sql);
	}
}
