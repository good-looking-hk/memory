package testfordb;

import java.awt.GridLayout;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Modify {
	JFrame frame = new JFrame("�޸�");
	JTextArea ta = new JTextArea();
	JTextField tf_id = new JTextField();
	JTextField tf_name = new JTextField();
	JTextField tf_point = new JTextField();
	public Modify() throws Exception{
		ResultSet rs = new DatabaseConnection().show();		
		while(rs.next()){
			String id = rs.getString("id");
			String name = rs.getString("name");
			String point = rs.getString("point");
			ta.append(id+"--"+name+"--"+point+"\n");
		}
		init();
	}
	private void init() {
		frame.setLayout(new GridLayout(4,0));
		frame.add(ta);
		frame.add(tf_id);
		frame.add(tf_name);
		frame.add(tf_point);
		frame.setVisible(true);
		frame.setSize(300,400);
		frame.setLocationRelativeTo(null);
	}
}
