package testfordb;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Main{
	static JButton button_show,button_add,button_modify,button_delete;
	static JFrame frame = new JFrame("���ݿ⹤��");
	public static void main(String[] args) {
		JFrame frame = new JFrame("���ݿ⹤��");
		button_show = new JButton("�鿴");
		button_add = new JButton("����");
		button_modify = new JButton("�޸�");
		button_delete = new JButton("ɾ��");
		frame.setLayout(new GridLayout(4,0));
		frame.add(button_show);
		frame.add(button_add);
		frame.add(button_modify);
		frame.add(button_delete);
		addListener_to_button();
		frame.setSize(300,400);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
	public static void addListener_to_button(){
		button_show.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
					try {
						 new Show();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
			}
		});
		button_add.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					new Add();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		});
		button_delete.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					new Drop();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		});
		button_modify.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				try {
					new Modify();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		});
	}
}