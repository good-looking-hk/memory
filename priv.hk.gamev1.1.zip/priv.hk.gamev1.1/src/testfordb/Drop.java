package testfordb;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Drop {
	JFrame frame = new JFrame("ɾ��");
	JTextArea ta = new JTextArea();
	JTextField tf = new JTextField();
	JButton button = new JButton("ok");
	public Drop() throws Exception{
		ResultSet rs = new DatabaseConnection().show();		
		while(rs.next()){
			String id = rs.getString("id");
			String name = rs.getString("name");
			String point = rs.getString("point");
			ta.append(id+"--"+name+"--"+point+"\n");
		}
		init();
	}
	private void init() {
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String sql = "delete from player where id="+tf.getText();
				System.out.println(sql);
				System.out.println("���Ϊ"+tf.getText()+"��ɾ��");
				try {
					DatabaseConnection.delete(sql);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		frame.setLayout(new GridLayout(3,0));
		frame.add(ta);
		frame.add(tf);
		frame.add(button);
		frame.setVisible(true);
		frame.setSize(300,400);
		frame.setLocationRelativeTo(null);
	}
}
