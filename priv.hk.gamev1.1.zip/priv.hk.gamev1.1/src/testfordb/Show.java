package testfordb;

import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JTextArea;

public class Show {
	JFrame frame = new JFrame("�鿴");
	JTextArea ta = new JTextArea();
	public Show() throws Exception{
		frame.add(ta);
		ResultSet rs = new DatabaseConnection().show();		
		while(rs.next()){
			String id = rs.getString("id");
			String name = rs.getString("name");
			String point = rs.getString("point");
			ta.append(id+"--"+name+"--"+point+"\n");
		}
		frame.setSize(300,400);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
}
