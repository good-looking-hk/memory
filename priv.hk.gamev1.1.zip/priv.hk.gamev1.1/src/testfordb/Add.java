package testfordb;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
public class Add {
	JFrame frame = new JFrame("����");
	JTextArea ta = new JTextArea();
	JTextField tf_id = new JTextField();
	JTextField tf_name = new JTextField();
	JTextField tf_point = new JTextField();
	JButton button = new JButton("ok");
	public Add() throws SQLException, Exception{
		ResultSet rs = new DatabaseConnection().show();		
		while(rs.next()){
			String id = rs.getString("id");
			String name = rs.getString("name");
			String point = rs.getString("point");
			ta.append(id+"--"+name+"--"+point+"\n");
		}
		init();
	}
	
	public void init(){
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String sql = "insert into player values ("+tf_id.getText()+",'"+tf_name.getText()+"',"+tf_point.getText()+")";
				System.out.println(sql);
				try {
					DatabaseConnection.add(sql);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		frame.setLayout(new GridLayout(5,0));
		frame.add(ta);
		frame.add(tf_id);
		frame.add(tf_name);
		frame.add(tf_point);
		frame.add(button);
		frame.setVisible(true);
		frame.setSize(300,400);
		frame.setLocationRelativeTo(null);
	}
}
