package test;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.StringTokenizer;
 
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
 
public class ClientChatUI extends JFrame implements ActionListener{                  
	JButton bu_send;
	private String userName;
	private JTextArea jta_recive=new JTextArea(15,25);
	private JComboBox jcb_users=new JComboBox();
	 final JTextField jtf_send=new JTextField(20);
	 private File myfile;
	public ClientChatUI(String userName)
	{
		this.userName=userName;
		init();
		showFrame();
	}
	private void init()
	{
		TextField name_txt = new TextField();
		java.awt.List list1 = new java.awt.List(16);
		JLabel la_name=new JLabel("���յ�����Ϣ��");
		JLabel la_users=new JLabel("���͵���Ϣ:");
		JButton bu_send=new JButton("����");
		JButton bu_history=new JButton("�����¼");
		add(la_name);
		add(jta_recive);
		add(la_users);
		add(jtf_send);
		add(jcb_users);
		add(bu_history);
		jcb_users.addItem("����");
		jcb_users.addItem("����");
		jcb_users.addItem("����");
		add(bu_send);
		bu_send.addActionListener(this);
		bu_history.addActionListener(this);
		setVisible(true);
	}
 
	public  void showFrame() {
		this.setTitle("netJava:��ӭ"+this.userName);
		FlowLayout f1=new FlowLayout(0);
		this.setLayout(f1);
		this.setSize(300,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	    
	}
 
	public static void main(String args[])
	{
		 ClientChatUI cc=new ClientChatUI("������");
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand()=="����")
		{
		String reciver=(String) jcb_users.getSelectedItem();
		reciver=reciver.trim();//ȥ���ո�
		String content=jtf_send.getText();
		jta_recive.append(userName+"��"+reciver+"˵:"+content+"\r\n");
		jtf_send.setText("");
		writeLog(jta_recive.getText());
		}
		else if(e.getActionCommand()=="�����¼")
		{
			jta_recive.setText("");
			jta_recive.append("�����¼��"+"\n");
			readLog();
		}
	}
	private void writeLog(String message)
	{
		myfile=new File("D:\\a.log");
		FileOutputStream fOutputStream=null;
		try {
			fOutputStream=new FileOutputStream(myfile);
			fOutputStream.write(message.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			try {
				fOutputStream.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}
	}
	
	private void readLog() {
		byte [] b = new byte[1024];
		FileInputStream fin = null;
		try
		{ 
			fin = new FileInputStream(myfile);
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		BufferedInputStream buff = new BufferedInputStream(fin);
			try {
				while ( buff.read(b, 0, 1024) != -1)
				{
					jta_recive.append(new String(b));
				}
				fin.read(b);
			} catch (IOException e1) {
				e1.printStackTrace();
				System.err.println("2");
				}
	}
	}
 