package test;

import java.util.Scanner;

public class Test{
	public static void main(String[] args) {
		byte b=011;
		byte a=11;
		System.out.println(b);
		System.out.println(a);
	}
}