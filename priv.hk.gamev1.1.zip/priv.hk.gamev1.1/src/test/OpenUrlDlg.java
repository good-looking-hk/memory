package test;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class OpenUrlDlg extends JDialog{
	public final static int ACTION_OPEN = 1;
	public final static int ACTION_CANNEL = 0;
	private String nameUrlDefault = null;
	private int intAction = ACTION_CANNEL;
	protected JFrame frameOwner = null;
	JPanel panelInput = new JPanel();
	GridLayout gridLayout = new GridLayout();
	FlowLayout flowLayout = new FlowLayout();
	JLabel jLabel = new JLabel();
	JTextField txtUrl = new JTextField();
	JPanel panelCmd = new JPanel();
	JButton cmdOpen = new JButton();
	JButton cmdCancel = new JButton();
	public OpenUrlDlg(JFrame frame,String nameUrlDefalut){
		super(frame,"Open Url",true);
		frameOwner = frame;
		this.nameUrlDefault = nameUrlDefalut;
		try{
			jbInit();
			pack();
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	 void jbInit() throws Exception {
		panelInput.setLayout(flowLayout);
		this.setTitle("Open Url");
		this.getContentPane().setLayout(gridLayout);
		gridLayout.setRows(2);
		gridLayout.setColumns(1);
		jLabel.setForeground(Color.red);
		jLabel.setText("URL:");
		cmdOpen.setBackground(new Color(180,255,50));
		cmdOpen.setForeground(Color.magenta);
		cmdOpen.setText("Open");
		txtUrl.setText(nameUrlDefault);
		cmdOpen.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				cmdOpen_actionPerformed(e);
			}
		});
		cmdCancel.setBackground(new Color(180,255,150));
		cmdCancel.setForeground(Color.magenta);
		cmdCancel.setText("Cancel");
		cmdCancel.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				cmdCancel_actionPerformed(e);
			}
		});
		panelCmd.setBackground(Color.orange);
		panelInput.setBackground(Color.orange);
		panelInput.add(jLabel,null);
		panelInput.add(txtUrl,null);
		txtUrl.setColumns(30);
		this.getContentPane().add(panelInput,null);
		this.getContentPane().add(txtUrl,null);
		panelCmd.add(cmdOpen,null);
		panelCmd.add(cmdCancel,null);
		this.pack();
		this.autoPosition();
		this.setResizable(false);
	}
	public void addNotify(){
		this.setBackground(Color.lightGray);
		super.addNotify();
		autoPosition();
	}
	
	public void autoPosition(){
		Dimension dim;
		Dimension dimFrame;
		Dimension dimDialog;
		Dimension dimScreen;
		Point point;
		Insets inset;
		point = frameOwner.getLocationOnScreen();
		dimFrame = frameOwner.getSize();
		dimDialog = this.getSize();
		point.y = point.y+(int)(dimFrame.getHeight()-dimDialog.getHeight())/2;
		this.setLocation(point);
	}
	public String getUrl(){
		String nameUrl;
		nameUrl = txtUrl.getText();
		return (nameUrl);
	}
	
	void cmdOpen_actionPerformed(ActionEvent e){
		this.setAction(this.ACTION_OPEN);
		this.dispose();
	}
	
	void cmdCancel_actionPerformed(ActionEvent e){
		this.setAction(this.ACTION_CANNEL);
		this.dispose();
	}
	protected void setAction(int intAction){
		this.intAction = intAction;
	}
	
	public int getAction(){
		return intAction;
	}
	public OpenUrlDlg(){
		this(null,"");
		
	}
}
