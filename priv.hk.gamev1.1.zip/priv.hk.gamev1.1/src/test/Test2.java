package test;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import priv.hk.game.config.ConfigFactory;
import priv.hk.game.config.GameConfig;
import priv.hk.game.config.LayerConfig;
import priv.hk.game.ui.BasicLayer;

public class Test2{
	
	List<BasicLayer> layers;
	
	static List<LayerConfig> layersCfg;
	
	public Test2() throws Exception {
		//
		GameConfig cfg = ConfigFactory.getGameConfig();
		
		layersCfg = cfg.getLayersConfig();
		
		layers = new ArrayList<BasicLayer>(layersCfg.size());
		
		for(LayerConfig layerCfg : layersCfg){
			Class<?> cls = Class.forName(layerCfg.getClassName());
			Constructor ctr = cls.getConstructor(int.class,int.class,int.class,int.class);
			BasicLayer l = (BasicLayer)ctr.newInstance(layerCfg.getX(),layerCfg.getY(),
					layerCfg.getW(),layerCfg.getH());
			layers.add(l);
		}
	}
	public static void main(String[] args) throws Exception {
		new Test2();
	}
}

